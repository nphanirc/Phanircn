package wowautomation;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Month;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Pillar_of_the_Month{

	static XSSFSheet sheet,sheet1;
	static XSSFWorkbook workbook;
	static XSSFRow row;
	static XSSFCell cell;
	static int a,b,Rows2,Cols2;
	static int Rows1;
	static int Cols1;	
	static String CellData;
	static int ExcelColNum_Index;
	static String BlankValue;
	
	static File filepath=new File(System.getProperty("user.dir")+"\\src\\testData\\WOW_Pillar_Awards.xlsx");
	static File file = new File(System.getProperty("user.dir")+"\\src\\ObjectRepository\\Master_OR.properties");
	static WebDriver driver;
public static void main(String[] args) throws InterruptedException, IOException, AWTException, ParseException {

	Pillar_of_the_Month_flow();
	driver.close();
	//Thread.getDefaultUncaughtExceptionHandler();
	}
	
public static Properties getObjectProperties()
	{
		File file = new File(System.getProperty("user.dir")+"\\src\\ObjectRepository\\Master_OR.properties");
		FileInputStream fileInput = null;
		try {
			     fileInput = new FileInputStream(file);
			     } catch (FileNotFoundException e) {
			     e.printStackTrace();
		 }
		 Properties properties = new Properties(); 
		 try {
			     properties.load(fileInput);
		 	     } catch (IOException e) {
			     e.printStackTrace();
		 } 
		 return properties;   
	}
private static void robot_pagedown() throws AWTException {
	Robot robot = new Robot();
    robot.keyPress(KeyEvent.VK_PAGE_DOWN);
    robot.keyRelease(KeyEvent.VK_PAGE_DOWN);
}
public static int GetColumnIndex_FromExcel(String WorkbookName,String SheetName,String ColName) throws IOException
{
	FileInputStream fis = new FileInputStream(filepath);
	workbook= new XSSFWorkbook(fis);
	for (int i = 0; i < workbook.getNumberOfSheets(); i++) 
	{
		if (workbook.getSheetName(i).equals(SheetName)) 
		{
		    sheet1 = workbook.getSheetAt(i);
			Rows1 = sheet.getLastRowNum()-sheet.getFirstRowNum();
			//Cols1 = sheet.getRow(i).getLastCellNum()-sheet.getRow(i).getFirstCellNum();
			Cols1 = sheet.getRow(i).getLastCellNum();
		}
	}			
		getcolumnindex:
		for (int j = 0; j <Rows1; j++) 
			{
				for (int k=0; k<=Cols1; k++) 
				{
					CellData= sheet.getRow(j).getCell(k).toString();
					if (CellData.equals(ColName)) 
					{
						ExcelColNum_Index=k;
						break getcolumnindex;
					}
				}
			}
	return ExcelColNum_Index;
}

@SuppressWarnings("unused")
public static String GetDataFromEXCEL(String WorkbookName,String SheetName,String ColName,int RowNumber) throws IOException
{
	FileInputStream fis = new FileInputStream(filepath);
	workbook = new XSSFWorkbook(fis);
	for (int i = 0; i <workbook.getNumberOfSheets(); i++) 
	{
		if (workbook.getSheetName(i).contains("WOW_Pillar_Nominations")) 
		{
			sheet=workbook.getSheetAt(i);
	
			Rows2 = sheet.getLastRowNum();
			Cols2 = sheet.getRow(i).getLastCellNum();

	getCellData:
	for (a = RowNumber; a <=Rows2; a++) 
	{
		for (b = 0; b <Cols2; b++) 
		{
			int ExcelColNum_Index = GetColumnIndex_FromExcel(WorkbookName,SheetName,ColName);
			if(sheet.getRow(a).getCell(ExcelColNum_Index)==null)
			{
				CellData="";
			}
			else
			{
			CellData=sheet.getRow(a).getCell(ExcelColNum_Index).toString();
			}
			break getCellData;
		}
	}
	}
	}
		//return isBlank(CellData);
	return CellData;
}
public String isBlank(String Value)
{
	if (Value.isEmpty()) 
	{
		BlankValue="blank";
		} else {
		BlankValue=Value;	
	}
	return BlankValue;
}

public static void setcellvaluestatus(int j,String status) throws IOException{
	  FileInputStream fis = new FileInputStream(filepath);
	  workbook = new XSSFWorkbook(fis);
	  sheet=workbook.getSheet("WOW_Pillar_Nominations");
	  Cols2 = sheet.getRow(j).getLastCellNum();
	  row = sheet.getRow(j);  
	  cell = row.createCell(Cols2-1);
	  cell.setCellValue(status);	
	  FileOutputStream outFile =new FileOutputStream(filepath);
	  workbook.write(outFile);
	  outFile.flush();
	  //fis.close();
	  outFile.close();
}

public static void catch_exception_maxlength(int j) throws IOException, InterruptedException{
	  Properties properties = getObjectProperties();
	  driver.findElement(By.xpath(properties.getProperty("obj_charactercount_errorpopup"))).click();
	  WebDriverWait wait = new WebDriverWait(driver,10);
	  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(properties.getProperty("obj_Cancel"))));
	  driver.findElement(By.xpath(properties.getProperty("obj_Cancel"))).click();
	  setcellvaluestatus(j,"Not uploaded due to max length");
	  Thread.sleep(2000);
	  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(properties.getProperty("obj_asssearch"))));
	  driver.findElement(By.xpath(properties.getProperty("obj_asssearch"))).clear();
	  Thread.sleep(1000);
}

public static void catch_Criteriaerror(int j) throws IOException, InterruptedException{
	 Properties properties = getObjectProperties();
	  try{
	  if(driver.findElement(By.xpath(properties.getProperty("obj_criteria_errorpopup"))).isDisplayed()){
		  driver.findElement(By.xpath(properties.getProperty("obj_criteria_errorpopup"))).click();
		  WebDriverWait wait = new WebDriverWait(driver,10);
		  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(properties.getProperty("obj_Cancel"))));
		  driver.findElement(By.xpath(properties.getProperty("obj_Cancel"))).click();
		  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(properties.getProperty("obj_asssearch"))));
		  driver.findElement(By.xpath(properties.getProperty("obj_asssearch"))).clear();
		  Thread.sleep(1000);
		  setcellvaluestatus(j,"Not Uploaded due to insufficient criteria");
	  }}
	  catch(Exception e){
	  WebDriverWait wait = new WebDriverWait(driver,30);
	  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(properties.getProperty("obj_asssearch"))));
	  driver.findElement(By.xpath(properties.getProperty("obj_asssearch"))).clear();
	  setcellvaluestatus(j,"Uploaded");
	  Thread.sleep(1000);
	  }
}
public static void Pillar_of_the_Month_flow() throws InterruptedException, IOException, AWTException, ParseException{

	   
	Properties properties = getObjectProperties();
	System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\chromedriver.exe");
  	ChromeOptions options = new ChromeOptions();
  	options.addArguments("disable-infobars");
  	driver = new ChromeDriver(options);
  	try{
  		  Thread.sleep(3000);  
  	}catch(Exception e){
  		  
  	}
  	driver.manage().window().maximize();
  	Thread.sleep(3000);
  	driver.get(properties.getProperty("URL"));
    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    JLabel jUserName = new JLabel("User Name");
    JTextField userName = new JTextField();
    JLabel jPassword = new JLabel("Password");
    JTextField password = new JPasswordField();
    Object[] loginwindw = {jUserName, userName, jPassword, password};
    int result = JOptionPane.showConfirmDialog(null, loginwindw, "Please Enter Username and Password ", JOptionPane.OK_CANCEL_OPTION);

    if (result == JOptionPane.OK_OPTION) 
    {
        String userNameValue = userName.getText();
        String passwordValue = password.getText();  
    
    driver.findElement(By.xpath(properties.getProperty("obj_username"))).sendKeys(userNameValue);
	driver.findElement(By.xpath(properties.getProperty("obj_password"))).sendKeys(passwordValue);
	driver.findElement(By.xpath(properties.getProperty("obj_loginbtn"))).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath(properties.getProperty("obj_down"))).click();
	Thread.sleep(2000);
	driver.navigate().refresh();
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	try{WebElement element = driver.findElement(By.xpath(properties.getProperty("obj_Nominationbtn")));
	Actions actions = new Actions(driver);
	actions.moveToElement(element).click().perform();
	}catch(Exception e){
	e.printStackTrace();
	}
	driver.navigate().refresh();
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
    }
    else
    {
    JOptionPane.showMessageDialog(null,"Terminated by user");
    System.exit(0);
    }
    	
	
//-----------------------------------------reading from excel---------------------------------------	
	FileInputStream fis = new FileInputStream(filepath);
	workbook = new XSSFWorkbook(fis);
	for (int i = 0; i <workbook.getNumberOfSheets(); i++) 
	{
		if (workbook.getSheetName(i).contains("WOW_Pillar_Nominations")) 
		{
			sheet=workbook.getSheetAt(i);
			int Rows = sheet.getLastRowNum();
			int Cols = sheet.getRow(i).getLastCellNum();
			
			for (int j = 1; j <=Rows; j++) 
			{			
				 String Award_Category=GetDataFromEXCEL("WOW_Pillar_Awards","WOW_Pillar_Nominations","Award Category",j);
				 String Citation=      GetDataFromEXCEL("WOW_Pillar_Awards","WOW_Pillar_Nominations","Citation",j);
				 String Criteria_D1 =  GetDataFromEXCEL("WOW_Pillar_Awards","WOW_Pillar_Nominations","Criteria D1",j);
				 String Criteria_D2=   GetDataFromEXCEL("WOW_Pillar_Awards","WOW_Pillar_Nominations","Criteria D2",j);
				 String Criteria_D3=   GetDataFromEXCEL("WOW_Pillar_Awards","WOW_Pillar_Nominations","Criteria D3",j);
				 String Criteria_D4=   GetDataFromEXCEL("WOW_Pillar_Awards","WOW_Pillar_Nominations","Criteria D4",j);
				 String Criteria_T1 =  GetDataFromEXCEL("WOW_Pillar_Awards","WOW_Pillar_Nominations","Criteria T1",j);
				 String Criteria_T2=   GetDataFromEXCEL("WOW_Pillar_Awards","WOW_Pillar_Nominations","Criteria T2",j);
				 String Criteria_T3=   GetDataFromEXCEL("WOW_Pillar_Awards","WOW_Pillar_Nominations","Criteria T3",j);
				 String Criteria_O1 =  GetDataFromEXCEL("WOW_Pillar_Awards","WOW_Pillar_Nominations","Criteria O1",j);
				 String Criteria_O2=   GetDataFromEXCEL("WOW_Pillar_Awards","WOW_Pillar_Nominations","Criteria O2",j);
				 String Criteria_O3=   GetDataFromEXCEL("WOW_Pillar_Awards","WOW_Pillar_Nominations","Criteria O3",j);
				 String Criteria_O4=   GetDataFromEXCEL("WOW_Pillar_Awards","WOW_Pillar_Nominations","Criteria O4",j);
				 String Criteria_O5 =  GetDataFromEXCEL("WOW_Pillar_Awards","WOW_Pillar_Nominations","Criteria O5",j);
				 String Criteria_B1=   GetDataFromEXCEL("WOW_Pillar_Awards","WOW_Pillar_Nominations","Criteria B1",j);
				 String Criteria_B2=   GetDataFromEXCEL("WOW_Pillar_Awards","WOW_Pillar_Nominations","Criteria B2",j);
				 String Criteria_B3=   GetDataFromEXCEL("WOW_Pillar_Awards","WOW_Pillar_Nominations","Criteria B3",j);
				 String Associate_ID = GetDataFromEXCEL("WOW_Pillar_Awards","WOW_Pillar_Nominations","Associate Id",j);
				 String Month1 =       GetDataFromEXCEL("WOW_Pillar_Awards","WOW_Pillar_Nominations","Month",j);
				 String Status_1 =     GetDataFromEXCEL("WOW_Pillar_Awards","WOW_Pillar_Nominations","status",j);

				
	try{
	SimpleDateFormat monthParse = new SimpleDateFormat("MM");
	SimpleDateFormat monthDisplay = new SimpleDateFormat("MMMM");
	String Month_Name = monthDisplay.format(monthParse.parse(Month1));       	 
	driver.findElement(By.xpath(properties.getProperty("obj_asssearch"))).click();
	driver.findElement(By.xpath(properties.getProperty("obj_asssearch"))).sendKeys(Associate_ID);
	driver.findElement(By.xpath(properties.getProperty("obj_searchbtn"))).click();
	driver.findElement(By.xpath(properties.getProperty("obj_selemployee"))).click();
	Thread.sleep(2000);	
	Select selaward = new Select(driver.findElement(By.xpath(properties.getProperty("obj_Award"))));
	selaward.selectByVisibleText("Pillar of the Month");
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
//------------------------------------------------------------------------------------------------------	  
	  if(Award_Category.equalsIgnoreCase("Delivery")){
	  Select selawardcat = new Select(driver.findElement(By.xpath(properties.getProperty("obj_Award_Category"))));
	  selawardcat.selectByVisibleText(Award_Category);
	  driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
	  Select selawardcatmon = new Select(driver.findElement(By.xpath(properties.getProperty("obj_Award_Cycle"))));
	  Thread.sleep(3000);
	  selawardcatmon.selectByVisibleText(Month_Name);
	  driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
	 try{ 
	  driver.findElement(By.xpath(properties.getProperty("Criteria_1"))).click();
	  driver.findElement(By.xpath(properties.getProperty("Criteria_1"))).sendKeys(Criteria_D1);
	  robot_pagedown();
	  Thread.sleep(2000);
	  driver.findElement(By.xpath(properties.getProperty("Criteria_2"))).click();
	  driver.findElement(By.xpath(properties.getProperty("Criteria_2"))).sendKeys(Criteria_D2);
	  robot_pagedown();
	  Thread.sleep(2000);
	  driver.findElement(By.xpath(properties.getProperty("Criteria_3"))).click();
	  driver.findElement(By.xpath(properties.getProperty("Criteria_3"))).sendKeys(Criteria_D3);
	  robot_pagedown();
	  Thread.sleep(2000);
	  driver.findElement(By.xpath(properties.getProperty("Criteria_4"))).click();
	  driver.findElement(By.xpath(properties.getProperty("Criteria_4"))).sendKeys(Criteria_D4);
   	  driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
	  driver.findElement(By.xpath(properties.getProperty("obj_Justification"))).click();
	  driver.findElement(By.xpath(properties.getProperty("obj_Justification"))).sendKeys(Citation);
	  Thread.sleep(2000);
	  robot_pagedown();
	  Thread.sleep(2000);
	  driver.findElement(By.xpath(properties.getProperty("obj_Submit"))).click();
	  driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
      
	  catch_Criteriaerror(j);

	  }catch(Exception e){
		  
		  catch_exception_maxlength(j);
	  }

//-------------------------------------------------------------------------------------------------------------------   	  
	  }else if (Award_Category.equalsIgnoreCase("Training & Mentoring")){
		  Select selawardcat = new Select(driver.findElement(By.xpath(properties.getProperty("obj_Award_Category"))));
		  selawardcat.selectByVisibleText(Award_Category);
		  driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		  Select selawardcatmon = new Select(driver.findElement(By.xpath(properties.getProperty("obj_Award_Cycle"))));
		  Thread.sleep(3000);
		  selawardcatmon.selectByVisibleText(Month_Name);
		  driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS); 
		  try{
		  driver.findElement(By.xpath(properties.getProperty("Criteria_1"))).click();
		  driver.findElement(By.xpath(properties.getProperty("Criteria_1"))).sendKeys(Criteria_T1);
		  robot_pagedown();
		  Thread.sleep(2000);
		  driver.findElement(By.xpath(properties.getProperty("Criteria_2"))).click();
		  driver.findElement(By.xpath(properties.getProperty("Criteria_2"))).sendKeys(Criteria_T2);
		  robot_pagedown();
		  Thread.sleep(2000);
		  driver.findElement(By.xpath(properties.getProperty("Criteria_3"))).click();
		  driver.findElement(By.xpath(properties.getProperty("Criteria_3"))).sendKeys(Criteria_T3);		  
	   	  driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		  driver.findElement(By.xpath(properties.getProperty("obj_Justification"))).click();
		  driver.findElement(By.xpath(properties.getProperty("obj_Justification"))).sendKeys(Citation);
		  Thread.sleep(2000);
		  robot_pagedown();
		  Thread.sleep(2000);
		  driver.findElement(By.xpath(properties.getProperty("obj_Submit"))).click();
		  driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		  
		  catch_Criteriaerror(j);

			  }catch(Exception e){
				  
				  catch_exception_maxlength(j);
			  }
//-------------------------------------------------------------------------------------------------------------------   
	  }else if(Award_Category.equalsIgnoreCase("Organization Initiative")){
		  Select selawardcat = new Select(driver.findElement(By.xpath(properties.getProperty("obj_Award_Category"))));
		  selawardcat.selectByVisibleText(Award_Category);
		  driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		  Select selawardcatmon = new Select(driver.findElement(By.xpath(properties.getProperty("obj_Award_Cycle"))));
		  Thread.sleep(3000);
		  selawardcatmon.selectByVisibleText(Month_Name);
		  driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		  try{
		  driver.findElement(By.xpath(properties.getProperty("Criteria_1"))).click();
		  driver.findElement(By.xpath(properties.getProperty("Criteria_1"))).sendKeys(Criteria_O1);
		  robot_pagedown();
		  Thread.sleep(2000);
		  driver.findElement(By.xpath(properties.getProperty("Criteria_2"))).click();
		  driver.findElement(By.xpath(properties.getProperty("Criteria_2"))).sendKeys(Criteria_O2);
		  robot_pagedown();
		  Thread.sleep(2000);
		  driver.findElement(By.xpath(properties.getProperty("Criteria_3"))).click();
		  driver.findElement(By.xpath(properties.getProperty("Criteria_3"))).sendKeys(Criteria_O3);
		  robot_pagedown();
		  Thread.sleep(2000);
		  driver.findElement(By.xpath(properties.getProperty("Criteria_4"))).click();
		  driver.findElement(By.xpath(properties.getProperty("Criteria_4"))).sendKeys(Criteria_O4);
		  robot_pagedown();
		  Thread.sleep(2000);
		  driver.findElement(By.xpath(properties.getProperty("Criteria_5"))).click();
		  driver.findElement(By.xpath(properties.getProperty("Criteria_5"))).sendKeys(Criteria_O5);		  
	   	  driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		  driver.findElement(By.xpath(properties.getProperty("obj_Justification"))).click();
		  driver.findElement(By.xpath(properties.getProperty("obj_Justification"))).sendKeys(Citation);
		  Thread.sleep(2000);
		  robot_pagedown();
		  Thread.sleep(2000);
		  driver.findElement(By.xpath(properties.getProperty("obj_Submit"))).click();
		  driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		  
		  catch_Criteriaerror(j);

			  }catch(Exception e){
				  
				  catch_exception_maxlength(j);
			  }
	 
//-------------------------------------------------------------------------------------------------------------------	  
	  
	  } else{
		  Select selawardcat = new Select(driver.findElement(By.xpath(properties.getProperty("obj_Award_Category"))));
		  selawardcat.selectByVisibleText(Award_Category);
		  driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		  Select selawardcatmon = new Select(driver.findElement(By.xpath(properties.getProperty("obj_Award_Cycle"))));
		  Thread.sleep(3000);
		  selawardcatmon.selectByVisibleText(Month_Name);
		  driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		  try{
		  driver.findElement(By.xpath(properties.getProperty("Criteria_1"))).click();
		  driver.findElement(By.xpath(properties.getProperty("Criteria_1"))).sendKeys(Criteria_B1);
		  robot_pagedown();
		  Thread.sleep(2000);
		  driver.findElement(By.xpath(properties.getProperty("Criteria_2"))).click();
		  driver.findElement(By.xpath(properties.getProperty("Criteria_2"))).sendKeys(Criteria_B2);
		  robot_pagedown();
		  Thread.sleep(2000);
		  driver.findElement(By.xpath(properties.getProperty("Criteria_3"))).click();
		  driver.findElement(By.xpath(properties.getProperty("Criteria_3"))).sendKeys(Criteria_B3);	
	   	  driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		  driver.findElement(By.xpath(properties.getProperty("obj_Justification"))).click();
		  driver.findElement(By.xpath(properties.getProperty("obj_Justification"))).sendKeys(Citation);
		  Thread.sleep(2000);
		  robot_pagedown();
		  Thread.sleep(2000);
		  driver.findElement(By.xpath(properties.getProperty("obj_Submit"))).click();
		  driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		  
		  catch_Criteriaerror(j);

			  }catch(Exception e){
				  catch_exception_maxlength(j);
			  }
	  }    
    }catch(Exception e){
		driver.findElement(By.xpath(properties.getProperty("obj_asssearch"))).clear();
		setcellvaluestatus(j,"Not Uploaded because associate is outside SBU");
	}  			
			}
}
}

	}
}
