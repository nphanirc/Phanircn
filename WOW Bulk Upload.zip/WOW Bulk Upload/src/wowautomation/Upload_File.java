package wowautomation;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Upload_File {

	/**
	 * @param args
	 * @throws InterruptedException
	 * @throws SQLException
	 */
	//static WebDriver driver;

	public static void main(String[] args) throws InterruptedException, EncryptedDocumentException, InvalidFormatException, IOException  {
		
		try{FileInputStream fis=new FileInputStream("C:\\selenium\\Data.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		//Workbook wb=WorkbookFactory.create(fis);
		XSSFSheet sh= wb.getSheetAt(0);
		
		//XSSFRow row=sh.getRow(1);
		//XSSFCell cell=row.getCell(0);
		XSSFRow row=sh.getRow(1);
		XSSFCell cell=row.createCell(3);
		cell.setCellValue("Selenium");
		//fis.close();
		FileOutputStream fos=new FileOutputStream("C:\\selenium\\Data.xlsx");
		wb.write(fos);
		fos.flush();
		fos.close();
		System.out.println("Excel File Written");
		}
		catch(Exception e){
			e.printStackTrace();
		}
			
		
		// TODO Auto-generated method stub
		
		/*System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chromedriver.exe");
	  	Thread.sleep(2000);
	  	driver.manage().window().maximize();
	  	ChromeOptions options = new ChromeOptions();
	  	options.addArguments("disable-infobars");
	  	driver = new ChromeDriver();
	  	try{
	  		  Thread.sleep(3000);  
	  	}catch(Exception e){
	  		  
	  	}
	  	driver.get("https://test.salesforce.com/");
		for (int i=1;i<=23;i++){

			try{if(driver.findElement(By.xpath("//input[@id='username']")).isDisplayed()){
				System.out.println("inside if");
				//report.updateTestLog("Step 21", "Verify that the currentId location is updated to HomeLocationID : "+fslId+" in fsl/InventoryItem region", "The currentId location is updated to HomeLocationID : "+fslId+" in fsl/InventoryItem region", "The currentId location was updated to HomeLocationID : "+fslId+" in fsl/InventoryItem region", Status.PASS);
				break;
			}
			}catch(Exception e){
				System.out.println("Printed");
				continue;
			}
		}
		System.out.println("not Printed");
		
			  //WebElement uploadElement = driver.findElement(By.xpath(properties.getProperty("obj_Fileupload")));
	  //uploadElement.sendKeys("C:\\Automation1\\TestData.xlsx");
	  //Thread.sleep(2000);
*/
/*            for(int i=0;i<=1;i++){
    	  	  boolean status=true;
    	  		while(status) {
	  		    try {
	  		    	driver.navigate().refresh();
	  		    	//Thread.sleep(3000);
	  		    	if(driver.findElement(By.xpath("//div[1]/span[text()='Status']/../following-sibling::div/span/span[text()='pending commit']")).isDisplayed()==true){
	  			break;
	  			}	
	  			} catch (Exception e) {
	  			driver.navigate().refresh();
	  			//Thread.sleep(3000);
	  			break;
	  			}
	  		}
	  	}*/
	  //Connection con = DriverManager.getConnection("jdbc:oracle:thin:@hcsmdmq2.na.jnj.com:1527:HCSOQ46","USER4IHUB","P0ker_05150");
	  //System.out.println(con.toString());
		
 /*       Calendar cal = Calendar.getInstance();
        SimpleDateFormat SDF = new SimpleDateFormat("dd_MMM_yyyy_hh:mm_a");
        String executiontime = SDF.format(cal.getTime());
        
		//String dateFormatString = "dd-MMM-yyyy hh:mm:ss a";
		System.out.println(executiontime);
		File Result_screenshots = new File(System.getProperty("user.dir")+"\\src\\result_screenshots\\"+executiontime);
		Result_screenshots.mkdir();*/
		
		
	  	//driver.get("http://demo.guru99.com/selenium/upload/");
	  	//Thread.sleep(1000);
        //WebElement uploadElement = driver.findElement(By.xpath("//input[@id='uploadfile_0']"));

        // enter the file path onto the file-selection input field
        //uploadElement.sendKeys("C:\\Automation1\\TestData.xls");
        //Thread.sleep(2000);  

		
	}
}
