import java.util.List;

public class CreditCardPayment extends Payment  // fill the code
{

	private String cardNumber;
	private String cvv;
	private String cardName;
	Double Totalamount;
	Invoice invoice = new Invoice();
	
	public CreditCardPayment() {
		
	}

	public CreditCardPayment(String name, Double amount, String cardNumber, String cvv, String cardName) {
		super(name, amount);
		this.cardNumber = cardNumber;
		this.cvv = cvv;
		this.cardName = cardName;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}

	public String getCardName() {
		return cardName;
	}

	public void setCardName(String cardName) {
		this.cardName = cardName;
	}



	@Override
	public Double calculateTotalAmount() throws InvalidPaymentException {
		
		int length_card = String.valueOf(cardNumber).length();
		int length_cvv = String.valueOf(cvv).length();
	   // Long  cardnumber = Longint.parseLong(cardNumber);
		//&& cardnumber.equals(getCardNumber())
		Totalamount = invoice.getTotalAmount();

		if((length_card != 16) && (length_cvv != 3) ){

				throw new InvalidPaymentException("Invalid Card Details");


		}else{
			Totalamount = 1.1 * amount;
		}
		// TODO Auto-generated method stub
		return Totalamount;
	} 
	
	}
	

