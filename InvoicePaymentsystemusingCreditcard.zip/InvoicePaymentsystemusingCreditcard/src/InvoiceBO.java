import java.sql.SQLException;
import java.util.List;
public class InvoiceBO {
	
	InvoiceDAO dao = new InvoiceDAO();

	public List<Invoice> getAllInvoice() throws ClassNotFoundException, SQLException {
		
		//fill the code
		return dao.getAllInvoices();
	}
	public void updateInvoiceDetails(int invoiceId,Double amount) throws ClassNotFoundException, SQLException {
		//fill the code
		dao.updateInvoiceDetails(invoiceId, amount);
	}
	
}
