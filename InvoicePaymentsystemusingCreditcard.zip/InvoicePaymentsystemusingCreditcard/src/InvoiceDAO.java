import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

// fill the code



public class InvoiceDAO {

	public List<Invoice> getAllInvoices() throws ClassNotFoundException, SQLException{
		// fill the code
		Connection con = DbConnection.getConnection();
		PreparedStatement  ps = con.prepareStatement("select * from invoice");
		ResultSet rs = ps.executeQuery();
		List<Invoice> invoiceList = new ArrayList<>();
		while(rs.next()) {			
			invoiceList.add(new Invoice(rs.getInt(1),rs.getString(2),rs.getInt(3), rs.getDouble(4), rs.getDouble(5), rs.getString(3)));
		}
		return invoiceList;

	}
	public void updateInvoiceDetails(Integer invoiceId, Double amount) throws ClassNotFoundException, SQLException{
		
		// fill the code
		Connection con = DbConnection.getConnection();
		PreparedStatement  ps = con.prepareStatement("UPDATE invoice SET balance = 25000 , payment_attempts = 2 where id = 1");
		ps.executeQuery();
		ps.executeUpdate();
		
	}
}
