

import static org.junit.Assert.fail;
import java.util.concurrent.TimeUnit;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import static org.junit.Assert.*;


public class WebTest {
	
	//static WebElement h1element;
	//static String helloWorldTxt;
	
	  public static WebDriver driver;
	  public static  WebElement h1element;
	  public static   String url ;
	  public static String helloWorldTxt;
	  private boolean acceptNextAlert = true;
	  private StringBuffer verificationErrors = new StringBuffer();



	   @Before
	   public void setUp() throws Exception {
		    driver = new HtmlUnitDriver(true);
		    driver.manage().window().maximize();
	        url = "http://apps.qa2qe.cognizant.e-box.co.in/WelcomeMessage/";
	        driver.manage().timeouts().implicitlyWait(500, TimeUnit.MILLISECONDS);
	   }


	  @Test
	  public void testWeb() throws Exception {
		 
	    driver.get(url);  
	      //fill your code
		Thread.sleep(5000);
		h1element = driver.findElement(By.tagName("h1"));
		By h1element = By.xpath("//h1/center[text()='WELCOME TO DATAX SHIPPING COMPANY']");
		 helloWorldTxt = driver.findElement(h1element).getText();
		 
		assertEquals(helloWorldTxt,"WELCOME TO DATAX SHIPPING COMPANY");
		
		System.out.println("Welcome Message Displayed");	
		
		if(isElementPresent(h1element)){
			System.out.println("Step1 : Welcome Message is Displayed");	
		}else{
			System.out.println("Step1 : Welcome Message was not Displayed");
		};
		
		System.out.println("End of program");
	    
	  }
	  

	  @After
	  public void tearDown() throws Exception {
		
	    driver.quit();
	    String verificationErrorString = verificationErrors.toString();
	    if (!"".equals(verificationErrorString)) {
	      fail(verificationErrorString);
	    }
	  }

	  private boolean isElementPresent(By by) {
	    try {
	      driver.findElement(by);
	      return true;
	    } catch (NoSuchElementException e) {
	      return false;
	    }
	  }

	  private boolean isAlertPresent() {
	    try {
	      driver.switchTo().alert();
	      return true;
	    } catch (NoAlertPresentException e) {
	      return false;
	    }
	  }

	  private String closeAlertAndGetItsText() {
	    try {
	      Alert alert = driver.switchTo().alert();
	      String alertText = alert.getText();
	      if (acceptNextAlert) {
	        alert.accept();
	      } else {
	        alert.dismiss();
	      }
	      return alertText;
	    } finally {
	      acceptNextAlert = true;
	    }
	  }    
}
