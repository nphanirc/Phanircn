
import java.util.regex.Pattern;
import java.io.File;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.ui.Select;

public class WebTest {
	  private WebDriver driver;
	  private String baseUrl;
	  private boolean acceptNextAlert = true;
	  private StringBuffer verificationErrors = new StringBuffer();
	  static WebElement h2element,sourceId,destinationId,weightId,costId,dateId,deliveryId;
	  static WebElement calculateId,resultId;

	public static String url;

	

  @Before
  public void setUp() throws Exception {
	   driver = new HtmlUnitDriver(true);
	   driver.manage().window().maximize();
	   url = "http://apps.qa2qe.cognizant.e-box.co.in/ShippingDetails/";
	   driver.manage().timeouts().implicitlyWait(500, TimeUnit.MILLISECONDS);}

  
  @Test
  public void testWeb() throws Exception {
	    driver.get(url);	    
      //fill your code	 
	    
	    Thread.sleep(3000);
	    sourceId = driver.findElement(By.id("source"));
	    destinationId = driver.findElement(By.id("destination"));
	    weightId = driver.findElement(By.id("weight"));
	    costId = driver.findElement(By.id("cost"));
	    dateId = driver.findElement(By.id("date"));
	    deliveryId = driver.findElement(By.id("delivery"));
	    calculateId = driver.findElement(By.id("calculate"));
	    h2element = driver.findElement(By.xpath("//h2"));
	    
	    String SourceAddress = "40,West cart road,Coimbatore";
	    String DestinationAddress = "40,West cart road,Coimbatore";
	    String TotalProductWeight = "40";
	    String Cost = "7";
	    String ShippingDate = "22/02/2017";
	    

	    
		//1 : Application launch
		if(h2element.isDisplayed()){
			System.out.println("Step1 : Application was successfully launched");	
		}else{
			System.out.println("Step1 : Application was not launched");
		};
		
		if(h2element.isDisplayed()){
			System.out.println("Step2 : h2 tag was present");	
		}else{
			System.out.println("Step2 : h2 tag was not present");
		};
		
		if(sourceId.isDisplayed()){
			System.out.println("Step3 : sourceId was present");	
		}else{
			System.out.println("Step3 : sourceId was not present");
		};
		
		if(weightId.isDisplayed()){
			System.out.println("Step4 : weight  was present");	
		}else{
			System.out.println("Step4 : weight was not present");
		};
		
		if(costId.isDisplayed()){
			System.out.println("Step5 : costId  was present");	
		}else{
			System.out.println("Step5 : costId was not present");
		};
		
		if(dateId.isDisplayed()){
			System.out.println("Step6 : dateId  was present");	
		}else{
			System.out.println("Step6 : dateId was not present");
		};
		
		if(deliveryId.isDisplayed()){
			System.out.println("Step7 : deliveryId  was present");	
		}else{
			System.out.println("Step7 : deliveryId was not present");
		};

		
		if(calculateId.isDisplayed()){
			System.out.println("Step8 : calculateId  was present");	
		}else{
			System.out.println("Step8 : calculateId was not present");
		};
		
					
		//2 : 	
	    sourceId.sendKeys(SourceAddress);
	    destinationId.sendKeys(DestinationAddress);
	    weightId.sendKeys(TotalProductWeight);
	    costId.sendKeys(Cost);
	    dateId.sendKeys(ShippingDate);
	    calculateId.click();
	    
	    resultId=driver.findElement(By.xpath("//div/b[text()='Shipping Details']"));
		String resultIdTXT =driver.findElement(By.xpath("//div/b[text()='Shipping Details']")).getText();
		
		if(resultId.isDisplayed()){
			System.out.println("Step2 : Shipping Details was dispayed");	
		}else{
			System.out.println("Step2 : Shipping Details was not dispayed");
		};

	 
		assertEquals(resultIdTXT,"Shipping Details");
		System.out.println("Step1 : Shipping Details was displayed");
		
		
		
		System.out.println("End of Program");
  }

@After
  public void tearDown() throws Exception {

    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}





