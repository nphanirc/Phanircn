

import java.util.regex.Pattern;
import java.io.File;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.ui.Select;

public class WebTest {
  private WebDriver driver;
  public static String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();
  static WebElement weight,air,road,ship,premium,calculate,result;
  static String result1,result2,result3;
  
  
  @Before
  public void setUp() throws Exception {
	   driver = new HtmlUnitDriver(true);
	   driver.manage().window().maximize();
	   baseUrl = "http://apps.qa2qe.cognizant.e-box.co.in/CostCalculation/";
	   driver.manage().timeouts().implicitlyWait(500, TimeUnit.MILLISECONDS);
  }
  
  @Test
  public void testWeb() throws Exception {
	    driver.get(baseUrl);	    	
         //fill your code
	    
	    Thread.sleep(3000);
	    weight = driver.findElement(By.id("weight"));
		air = driver.findElement(By.id("air"));
		road = driver.findElement(By.id("road"));
		ship = driver.findElement(By.id("ship"));
		premium = driver.findElement(By.id("premium"));
		calculate = driver.findElement(By.id("calculate"));
		String weight100 = "100";
				
		//1 : Application launch
		if(weight.isDisplayed()){
			System.out.println("Step1 : Application was successfully launched");	
		}else{
			System.out.println("Step1 : Application was not launched");
		};
		
		
		//2 : 	Check for the input	Air : 100 click calculate button
		weight.sendKeys(weight100);
		air.click();
		calculate.click();
		
		Thread.sleep(2000);
		WebElement textMessage1 = driver.findElement(By.xpath("//div[@id='result' and text()='Dear Customer, your total shipping cost is $100']"));
		
		if(textMessage1.isDisplayed()){
			System.out.println("Step2 : The Text 'Dear Customer,your total shipping cost is $100' was dispayed");	
		}else{
			System.out.println("Step2 : The Text 'Dear Customer,your total shipping cost is $100' was not dispayed");
		};
		
		String textMessage1TXT = textMessage1.getText();		 
		assertEquals(textMessage1TXT,"Dear Customer, your total shipping cost is $100");
		System.out.println("Step1 : h1 element was displayed 'DATAX Shipping Company'");
		
		
		//3 : 	Create a static variable named as result1(String) and store the String locator into the variable.
		result1 = driver.findElement(By.xpath("//div[@id='result' and text()='Dear Customer, your total shipping cost is $100']")).getText();
		System.out.println("result1: "+result1);
		
		
		//4 : 	Check for the input	Ship : 100	click calculate button
		Thread.sleep(2000);
		weight.clear();
		weight.sendKeys(weight100);
		ship.click();
		calculate.click();
		
		Thread.sleep(2000);
		WebElement textMessage2 = driver.findElement(By.xpath("//div[@id='result' and text()='Dear Customer, your total shipping cost is $70']"));
		result2 = driver.findElement(By.xpath("//div[@id='result' and text()='Dear Customer, your total shipping cost is $70']")).getText();
		
		if(textMessage2.isDisplayed()){
			System.out.println("Step3 : The Text 'Dear Customer,your total shipping cost is $70' was dispayed");	
		}else{
			System.out.println("Step3 : The Text 'Dear Customer,your total shipping cost is $70' was not dispayed");
		};
		
		
		//5 : 	Create a static variable named as result1(String) and store the String locator into the variable.
		System.out.println("result2: "+result2);
		
		//6 : 		Check for the input	Ship : 100	click calculate button
		Thread.sleep(2000);
		weight.clear();
		weight.sendKeys(weight100);
		road.click();
		calculate.click();
		
		Thread.sleep(2000);
		WebElement textMessage3 = driver.findElement(By.xpath("//div[@id='result' and text()='Dear Customer, your total shipping cost is $50']"));
		
		if(textMessage3.isDisplayed()){
			System.out.println("Step4 : The Text 'Dear Customer,your total shipping cost is $50' was dispayed");	
		}else{
			System.out.println("Step4 : The Text 'Dear Customer,your total shipping cost is $50' was not dispayed");
		};
		
		
		//7 : 	Create a static variable named as result1(String) and store the String locator into the variable.
		result3 = driver.findElement(By.xpath("//div[@id='result' and text()='Dear Customer, your total shipping cost is $50']")).getText();
		System.out.println("result3: "+result3);
		
		//8 - Additional step
		
		//6 : 		Check for the input	Ship : 100	click calculate button
		Thread.sleep(2000);
		weight.clear();
		weight.sendKeys(weight100);
		road.click();
		premium.click();
		calculate.click();
		
		System.out.println("End of program");
		driver.close();
  }

@After
  public void tearDown() throws Exception {

    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}




